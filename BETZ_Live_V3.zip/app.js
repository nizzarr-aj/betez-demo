const API_BASE = "https://betz-api.vercel.app/api/football";
let selected = null;
let currentSport = "all";

function esc(v) {
  return String(v ?? "").replace(/[&<>"']/g, s => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[s]));
}

function fmtTime(iso) {
  if (!iso) return "--:--";
  const d = new Date(iso);
  return d.toLocaleTimeString("fr-TN", {hour:"2-digit", minute:"2-digit"});
}

function statusLabel(f) {
  const short = f?.fixture?.status?.short || "";
  const elapsed = f?.fixture?.status?.elapsed;
  if (["HT"].includes(short)) return "MT";
  if (["FT","AET","PEN"].includes(short)) return "FIN";
  if (elapsed != null) return `${elapsed}'`;
  return short || "LIVE";
}

function leagueName(f) {
  return f?.league?.name || "Football";
}

function teams(f) {
  return {
    home: f?.teams?.home?.name || "Home",
    away: f?.teams?.away?.name || "Away",
    homeLogo: f?.teams?.home?.logo || "",
    awayLogo: f?.teams?.away?.logo || ""
  };
}

function renderTeam(name, logo) {
  return `<div class="team">${logo ? `<img src="${esc(logo)}" alt="">` : `<span class="logo-fallback">⚽</span>`}<b>${esc(name)}</b></div>`;
}

function renderLive(matches) {
  const box = document.getElementById("liveCards");
  if (!matches.length) {
    box.innerHTML = `<div class="emptyState">ما فماش مباريات مباشرة متاحة توّا.</div>`;
    return;
  }

  box.innerHTML = matches
    .filter(f => currentSport === "all" || leagueName(f))
    .map(f => {
      const t = teams(f);
      const hs = f?.goals?.home ?? 0;
      const as = f?.goals?.away ?? 0;
      return `<article class="match live-card" data-sport="Football" onclick='selectMatch(${JSON.stringify({
        home:t.home, away:t.away, score:`${hs} - ${as}`, league:leagueName(f), id:f.fixture?.id
      })})'>
        <span class="live">● LIVE ${esc(statusLabel(f))}</span>
        <small>${esc(leagueName(f))} • ${esc(f?.league?.country || "")}</small>
        <div class="teams">
          ${renderTeam(t.home,t.homeLogo)}
          <strong>${hs} - ${as}</strong>
          ${renderTeam(t.away,t.awayLogo)}
        </div>
        <div class="liveMeta"><span>${esc(f?.fixture?.venue?.name || "Live")}</span><span>${fmtTime(f?.fixture?.date)}</span></div>
      </article>`;
    }).join("");
}

function renderUpcoming(matches) {
  const box = document.getElementById("upcomingRows");
  if (!matches.length) {
    box.innerHTML = `<div class="emptyState">ما فماش مباريات اليوم متاحة.</div>`;
    return;
  }

  box.innerHTML = matches.slice(0, 12).map(f => {
    const t = teams(f);
    return `<div class="row" onclick='selectMatch(${JSON.stringify({
      home:t.home, away:t.away, score:"لم تبدأ", league:leagueName(f), id:f.fixture?.id
    })})'>
      <span>☆</span>
      <b>${esc(t.home)} × ${esc(t.away)}</b>
      <small>${fmtTime(f?.fixture?.date)} • ${esc(leagueName(f))}</small>
      <span class="virtualOdd">متابعة</span>
    </div>`;
  }).join("");
}

async function api(params) {
  const url = `${API_BASE}?${new URLSearchParams(params)}`;
  const r = await fetch(url, {cache:"no-store"});
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const data = await r.json();
  if (data.errors && Object.keys(data.errors).length) throw new Error(JSON.stringify(data.errors));
  return data.response || [];
}

async function loadLiveOnly() {
  const liveStatus = document.getElementById("liveStatus");
  try {
    liveStatus.textContent = "جاري تحديث المباريات...";
    const live = await api({live:"all"});
    renderLive(live);
    const now = new Date().toLocaleTimeString("fr-TN",{hour:"2-digit",minute:"2-digit"});
    document.getElementById("updated").textContent = `آخر تحديث ${now}`;
    liveStatus.textContent = `${live.length} مباراة مباشرة`;
  } catch (e) {
    console.error(e);
    liveStatus.textContent = "تعذر تحديث المباريات";
  }
}

async function loadAll() {
  const liveStatus = document.getElementById("liveStatus");
  const upcomingStatus = document.getElementById("upcomingStatus");
  liveStatus.textContent = "جاري جلب المباريات...";
  upcomingStatus.textContent = "جاري جلب مباريات اليوم...";

  try {
    const [live, today] = await Promise.all([
      api({live:"all"}),
      api({date:new Date().toISOString().slice(0,10)})
    ]);

    renderLive(live);
    renderUpcoming(today);

    const now = new Date().toLocaleTimeString("fr-TN",{hour:"2-digit",minute:"2-digit"});
    document.getElementById("updated").textContent = `آخر تحديث ${now}`;
    liveStatus.textContent = `${live.length} مباراة مباشرة`;
    upcomingStatus.textContent = `${today.length} مباراة اليوم`;
  } catch (e) {
    console.error(e);
    document.getElementById("liveCards").innerHTML =
      `<div class="emptyState">تعذر جلب البيانات. تأكد من اتصال الإنترنت وBackend.</div>`;
    document.getElementById("upcomingRows").innerHTML =
      `<div class="emptyState">تعذر جلب مباريات اليوم.</div>`;
    liveStatus.textContent = "خطأ في جلب البيانات";
    upcomingStatus.textContent = "خطأ";
  }
}

function filterSport(sport, btn) {
  currentSport = sport;
  document.querySelectorAll(".sports button").forEach(x => x.classList.remove("selected"));
  btn.classList.add("selected");
  if (sport === "Football") loadAll();
}

function selectMatch(m) {
  selected = m;
  document.getElementById("selection").innerHTML =
    `<div style="color:#20e7a0">اختيار مضاف ✓</div>
     <p><b>${esc(m.home)} × ${esc(m.away)}</b></p>
     <p>${esc(m.league)}</p>
     <p style="color:#8199a5">النتيجة: ${esc(m.score)}</p>`;
}

function demoConfirm() {
  if (!selected) {
    alert("أضف اختياراً أولاً");
    return;
  }
  showModal("تأكيد الاختيار", `
    <p><b>${esc(selected.home)} × ${esc(selected.away)}</b></p>
    <p>${esc(selected.league)}</p>
    <p style="color:#8ea4af;font-size:12px">هذا النظام يستخدم رصيداً افتراضياً فقط ولا ينفذ معاملات مالية.</p>
    <button class="action" onclick="closeModal()">موافق</button>
  `);
}

function showWallet() {
  showModal("محفظتي", `<h3>الرصيد الافتراضي: <span style="color:#20e7a0">245.50 TND</span></h3>
  <p>الرصيد مخصص للاختبار داخل الواجهة فقط.</p>`);
}

function showDemo(name) {
  showModal(name, `<p>هذا القسم موجود في الواجهة التجريبية وسيتم تطويره لاحقاً.</p>`);
}

function showModal(t,b) {
  document.getElementById("modalTitle").textContent = t;
  document.getElementById("modalBody").innerHTML = b;
  document.getElementById("modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
}

function scrollToMatches() {
  document.getElementById("matches").scrollIntoView({behavior:"smooth"});
}

loadAll();
// Free API plan: refresh live data every 15 minutes to stay within the daily quota.
setInterval(loadLiveOnly, 15 * 60 * 1000);
