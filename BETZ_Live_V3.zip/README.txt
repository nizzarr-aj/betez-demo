BETZ Live V3
- Frontend uses virtual/demo credits only.
- Live football data is fetched through the secure Vercel backend:
  https://betz-api.vercel.app/api/football
- No API key is included in this ZIP.
