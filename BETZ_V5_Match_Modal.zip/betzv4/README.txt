BETZ V4 — Live Sports + Virtual Bet Slip

Frontend demo for GitHub Pages.
Live football data is loaded through the secure Vercel backend.
The wallet, selections and tickets in this version are virtual/local only.
No real-money deposits, withdrawals or cash-out are implemented.
