const API_BASE = "https://betz-api.vercel.app/api/football";
let selections = [];
let currentSport = "all";
let virtualBalance = Number(localStorage.getItem("betz_virtual_balance") || "245.50");

function esc(v) {
  return String(v ?? "").replace(/[&<>"']/g, s => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[s]));
}

function fmtTime(iso) {
  if (!iso) return "--:--";
  const d = new Date(iso);
  return d.toLocaleTimeString("fr-TN", {hour:"2-digit", minute:"2-digit"});
}

function statusLabel(f) {
  const short = f?.fixture?.status?.short || "";
  const elapsed = f?.fixture?.status?.elapsed;
  if (["HT"].includes(short)) return "MT";
  if (["FT","AET","PEN"].includes(short)) return "FIN";
  if (elapsed != null) return `${elapsed}'`;
  return short || "LIVE";
}

function leagueName(f) {
  return f?.league?.name || "Football";
}

function teams(f) {
  return {
    home: f?.teams?.home?.name || "Home",
    away: f?.teams?.away?.name || "Away",
    homeLogo: f?.teams?.home?.logo || "",
    awayLogo: f?.teams?.away?.logo || ""
  };
}

function renderTeam(name, logo) {
  return `<div class="team">${logo ? `<img src="${esc(logo)}" alt="">` : `<span class="logo-fallback">⚽</span>`}<b>${esc(name)}</b></div>`;
}

function renderLive(matches) {
  const box = document.getElementById("liveCards");
  if (!matches.length) {
    box.innerHTML = `<div class="emptyState">ما فماش مباريات مباشرة متاحة توّا.</div>`;
    return;
  }

  box.innerHTML = matches
    .filter(f => currentSport === "all" || leagueName(f))
    .map(f => {
      const t = teams(f);
      const hs = f?.goals?.home ?? 0;
      const as = f?.goals?.away ?? 0;
      return `<article class="match live-card" data-sport="Football" onclick='openMatchModal(${JSON.stringify({
        home:t.home, away:t.away, score:`${hs} - ${as}`, league:leagueName(f), id:f.fixture?.id
      })})'>
        <span class="live">● LIVE ${esc(statusLabel(f))}</span>
        <small>${esc(leagueName(f))} • ${esc(f?.league?.country || "")}</small>
        <div class="teams">
          ${renderTeam(t.home,t.homeLogo)}
          <strong>${hs} - ${as}</strong>
          ${renderTeam(t.away,t.awayLogo)}
        </div>
        <div class="liveMeta"><span>${esc(f?.fixture?.venue?.name || "Live")}</span><span>${fmtTime(f?.fixture?.date)}</span></div>
      </article>`;
    }).join("");
}

function renderUpcoming(matches) {
  const box = document.getElementById("upcomingRows");
  if (!matches.length) {
    box.innerHTML = `<div class="emptyState">ما فماش مباريات اليوم متاحة.</div>`;
    return;
  }

  box.innerHTML = matches.slice(0, 12).map(f => {
    const t = teams(f);
    return `<div class="row" onclick='openMatchModal(${JSON.stringify({
      home:t.home, away:t.away, score:"لم تبدأ", league:leagueName(f), id:f.fixture?.id
    })})'>
      <span>☆</span>
      <b>${esc(t.home)} × ${esc(t.away)}</b>
      <small>${fmtTime(f?.fixture?.date)} • ${esc(leagueName(f))}</small>
      <span class="virtualOdd">متابعة</span>
    </div>`;
  }).join("");
}

async function api(params) {
  const url = `${API_BASE}?${new URLSearchParams(params)}`;
  const r = await fetch(url, {cache:"no-store"});
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const data = await r.json();
  if (data.errors && Object.keys(data.errors).length) throw new Error(JSON.stringify(data.errors));
  return data.response || [];
}

async function loadLiveOnly() {
  const liveStatus = document.getElementById("liveStatus");
  try {
    liveStatus.textContent = "جاري تحديث المباريات...";
    const live = await api({live:"all"});
    renderLive(live);
    const now = new Date().toLocaleTimeString("fr-TN",{hour:"2-digit",minute:"2-digit"});
    document.getElementById("updated").textContent = `آخر تحديث ${now}`;
    liveStatus.textContent = `${live.length} مباراة مباشرة`;
  } catch (e) {
    console.error(e);
    liveStatus.textContent = "تعذر تحديث المباريات";
  }
}

async function loadAll() {
  const liveStatus = document.getElementById("liveStatus");
  const upcomingStatus = document.getElementById("upcomingStatus");
  liveStatus.textContent = "جاري جلب المباريات...";
  upcomingStatus.textContent = "جاري جلب مباريات اليوم...";

  try {
    const [live, today] = await Promise.all([
      api({live:"all"}),
      api({date:new Date().toISOString().slice(0,10)})
    ]);

    renderLive(live);
    renderUpcoming(today);

    const now = new Date().toLocaleTimeString("fr-TN",{hour:"2-digit",minute:"2-digit"});
    document.getElementById("updated").textContent = `آخر تحديث ${now}`;
    liveStatus.textContent = `${live.length} مباراة مباشرة`;
    upcomingStatus.textContent = `${today.length} مباراة اليوم`;
  } catch (e) {
    console.error(e);
    document.getElementById("liveCards").innerHTML =
      `<div class="emptyState">تعذر جلب البيانات. تأكد من اتصال الإنترنت وBackend.</div>`;
    document.getElementById("upcomingRows").innerHTML =
      `<div class="emptyState">تعذر جلب مباريات اليوم.</div>`;
    liveStatus.textContent = "خطأ في جلب البيانات";
    upcomingStatus.textContent = "خطأ";
  }
}

function filterSport(sport, btn) {
  currentSport = sport;
  document.querySelectorAll(".sports button").forEach(x => x.classList.remove("selected"));
  btn.classList.add("selected");
  if (sport === "Football") loadAll();
updateBalanceUI();
}

function openMatchModal(m) {
  const exists = selections.some(x => String(x.id) === String(m.id));
  const scoreText = esc(m.score || "لم تبدأ");
  showModal("اختيارات المباراة", `
    <div class="matchModal">
      <div class="modalLeague">${esc(m.league || "Football")}</div>
      <h3>${esc(m.home)} <span>×</span> ${esc(m.away)}</h3>
      <div class="modalScore">${scoreText}</div>
      <div class="marketTitle">اختار نتيجة افتراضية</div>
      <div class="marketGrid">
        <button class="market" onclick='addSelectionFromModal(${JSON.stringify(m)}, "1", 1.80)'><b>1</b><span>${esc(m.home)}</span><strong>1.80</strong></button>
        <button class="market" onclick='addSelectionFromModal(${JSON.stringify(m)}, "X", 3.20)'><b>X</b><span>تعادل</span><strong>3.20</strong></button>
        <button class="market" onclick='addSelectionFromModal(${JSON.stringify(m)}, "2", 2.20)'><b>2</b><span>${esc(m.away)}</span><strong>2.20</strong></button>
      </div>
      ${exists ? `<p class="already">✓ المباراة موجودة في القسيمة</p>` : `<p class="hint">اضغط على اختيار باش يتضاف للقسيمة الافتراضية.</p>`}
    </div>`);
}

function addSelectionFromModal(m, pick, odd) {
  const exists = selections.some(x => String(x.id) === String(m.id));
  if (!exists) selections.push({...m, pick, odd});
  else selections = selections.map(x => String(x.id) === String(m.id) ? {...x, pick, odd} : x);
  renderSlip();
  closeModal();
  // على الهاتف الـBet Slip الجانبي مخفي، لذلك نظهر تأكيداً واضحاً بعد الإضافة.
  showModal("تمت الإضافة ✓", `<p><b>${esc(m.home)} × ${esc(m.away)}</b></p><p>الاختيار: <b>${esc(pick)}</b> — المعامل الافتراضي: <b>${Number(odd).toFixed(2)}x</b></p><button class="action" onclick="closeModal(); demoConfirm()">مراجعة القسيمة</button>`);
}

function selectMatch(m) {
  openMatchModal(m);
}

function removeSelection(id) {
  selections = selections.filter(x => String(x.id) !== String(id));
  renderSlip();
}

function renderSlip() {
  const box = document.getElementById("selection");
  if (!selections.length) {
    box.className = "empty";
    box.innerHTML = `أضف اختياراً<br><small>اضغط على بطاقة مباراة لإضافتها</small>`;
    return;
  }
  box.className = "selection-list";
  box.innerHTML = selections.map((m, i) => `
    <div class="pick">
      <div><b>${esc(m.home)} × ${esc(m.away)}</b><small>${esc(m.league)}</small></div>
      <span class="pickOdd">${m.odd.toFixed(2)}x</span>
      <button onclick="removeSelection('${esc(m.id)}')">×</button>
    </div>`).join("");
}

function demoConfirm() {
  if (!selections.length) {
    alert("أضف اختياراً أولاً");
    return;
  }
  const combined = selections.reduce((a, x) => a * x.odd, 1);
  showModal("قسيمة افتراضية", `
    <p><b>${selections.length}</b> اختيار(ات)</p>
    <p>المعامل الافتراضي: <b>${combined.toFixed(2)}x</b></p>
    <label style="display:block;margin:14px 0 6px">قيمة افتراضية (TND)</label>
    <input id="virtualStake" type="number" min="1" max="${virtualBalance.toFixed(2)}" value="10" style="width:100%;padding:12px;border-radius:10px;border:1px solid #29404a;background:#0b171c;color:#fff">
    <p style="color:#8ea4af;font-size:12px">الرصيد والنتائج افتراضية للاختبار فقط. لا توجد معاملات مالية أو سحب أموال.</p>
    <button class="action" onclick="placeVirtualTicket(${combined})">تأكيد افتراضي</button>
  `);
}

function placeVirtualTicket(combined) {
  const input = document.getElementById("virtualStake");
  const stake = Number(input?.value || 0);
  if (!Number.isFinite(stake) || stake <= 0 || stake > virtualBalance) {
    alert("أدخل قيمة صحيحة ضمن الرصيد الافتراضي");
    return;
  }
  virtualBalance = Number((virtualBalance - stake).toFixed(2));
  localStorage.setItem("betz_virtual_balance", virtualBalance.toFixed(2));
  const ticket = {
    id: Date.now(), date: new Date().toLocaleString("fr-TN"),
    stake, combined: Number(combined.toFixed(2)), selections: selections.map(x => ({home:x.home, away:x.away, league:x.league, odd:x.odd}))
  };
  const history = JSON.parse(localStorage.getItem("betz_virtual_history") || "[]");
  history.unshift(ticket);
  localStorage.setItem("betz_virtual_history", JSON.stringify(history.slice(0,30)));
  selections = [];
  renderSlip();
  closeModal();
  updateBalanceUI();
  showModal("تم حفظ القسيمة الافتراضية ✓", `<p>المبلغ الافتراضي: <b>${stake.toFixed(2)} TND</b></p><p>المعامل: <b>${combined.toFixed(2)}x</b></p><p style="color:#20e7a0">الرصيد الافتراضي المتبقي: ${virtualBalance.toFixed(2)} TND</p>`);
}

function updateBalanceUI() {
  document.querySelectorAll(".balance, .walletValue").forEach(el => el.textContent = `${virtualBalance.toFixed(2)} TND`);
}

function showWallet() {
  showModal("محفظتي الافتراضية", `<h3>الرصيد: <span class="walletValue" style="color:#20e7a0">${virtualBalance.toFixed(2)} TND</span></h3>
  <p>هذه محفظة اختبار داخل الموقع فقط، ولا تمثل أموالاً حقيقية ولا تدعم الإيداع أو السحب.</p>`);
}

function showHistory() {
  const history = JSON.parse(localStorage.getItem("betz_virtual_history") || "[]");
  if (!history.length) return showModal("سجل القسائم", `<p>لا توجد قسائم افتراضية بعد.</p>`);
  showModal("سجل القسائم الافتراضية", history.slice(0,10).map((t,i)=>`<div class="historyItem"><b>#${i+1} — ${t.stake.toFixed(2)} TND</b><small>${esc(t.date)} • ${t.combined.toFixed(2)}x</small></div>`).join(""));
}

function showDemo(name) {
  showModal(name, `<p>هذا القسم موجود في الواجهة التجريبية وسيتم تطويره لاحقاً.</p>`);
}

function showModal(t,b) {
  document.getElementById("modalTitle").textContent = t;
  document.getElementById("modalBody").innerHTML = b;
  document.getElementById("modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
}

function scrollToMatches() {
  document.getElementById("matches").scrollIntoView({behavior:"smooth"});
}

loadAll();
// Free API plan: refresh live data every 15 minutes to stay within the daily quota.
setInterval(loadLiveOnly, 15 * 60 * 1000);
