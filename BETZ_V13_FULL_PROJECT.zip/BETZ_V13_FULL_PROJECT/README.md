# BETZ V13 PRO

Complete GitHub-ready frontend project.

## Files
- `index.html` — main page
- `css/style.css` — full styling
- `js/app.js` — menu and filter interactions
- `assets/` — reserved for logos/images/icons

## Run
Open `index.html` or deploy the folder with GitHub Pages.

The displayed matches/odds are demo data and are not connected to a real betting provider.
