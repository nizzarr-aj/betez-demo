BETZ V6 - Markets + Mobile Bet Slip
Virtual/internal credits only. Live football data is loaded from the BETZ backend.
The match market UI includes multiple simulated markets for product/UI testing.
