let selected=null;
function pick(btn){
  document.querySelectorAll('.odds button,.row button').forEach(x=>x.classList.remove('picked'));
  btn.classList.add('picked');
  selected=btn.dataset.odd;
  document.getElementById('selection').innerHTML=`<div style="color:#20e7a0">اختيار مضاف ✓</div><p>Odd: <b>${selected}</b></p><p style="color:#8199a5">أدخل مبلغاً افتراضياً في النسخة التجريبية.</p>`;
}
function demoConfirm(){
  if(!selected){alert('أضف اختياراً أولاً');return}
  showModal('تأكيد الرهان التجريبي',`<p>Odd المختار: <b>${selected}</b></p><input class="field" placeholder="مبلغ تجريبي (TND)"><p style="color:#8ea4af;font-size:12px">هذه النسخة تستخدم أموالاً افتراضية فقط.</p><button class="action" onclick="alert('تم تسجيل الرهان التجريبي');closeModal()">تأكيد</button>`);
}
function showDeposit(){showModal('الإيداع — Demo',`<p>اختر وسيلة دفع تجريبية:</p><div class="field">D17 — Demo</div><div class="field">Flouci — Demo</div><div class="field">بطاقة — Demo</div><p style="color:#8ea4af;font-size:12px">لا توجد معاملات مالية حقيقية في هذه النسخة.</p>`)}
function showWallet(){showModal('محفظتي',`<h3>الرصيد التجريبي: <span style="color:#20e7a0">245.50 TND</span></h3><p>الرصيد هنا افتراضي ومخصص للاختبار.</p>`)}
function showWithdraw(){showModal('طلب سحب — Demo',`<p>الرصيد القابل للسحب: <b>245.50 TND</b></p><input class="field" placeholder="المبلغ"><input class="field" placeholder="وسيلة السحب — Demo"><button class="action" onclick="alert('تم إنشاء طلب سحب تجريبي');closeModal()">إرسال الطلب</button>`)}
function showModal(t,b){document.getElementById('modalTitle').textContent=t;document.getElementById('modalBody').innerHTML=b;document.getElementById('modal').classList.remove('hidden')}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function scrollToMatches(){document.getElementById('matches').scrollIntoView({behavior:'smooth'})}
