
const API_FOOTBALL="https://betz-api.vercel.app/api/football";
const API_BASKETBALL="https://betz-api.vercel.app/api/basketball";
const API_SPORTS="https://betz-api.vercel.app/api/sports";
const sports=[
 {id:'football',label:'⚽ Football',title:'Football'},
 {id:'basketball',label:'🏀 Basketball',title:'Basketball'},
 {id:'tennis',label:'🎾 Tennis',title:'Tennis'},
 {id:'handball',label:'🤾 Handball',title:'Handball'},
 {id:'volleyball',label:'🏐 Volleyball',title:'Volleyball'},
 {id:'hockey',label:'🏒 Hockey',title:'Hockey'},
 {id:'rugby',label:'🏉 Rugby',title:'Rugby'},
 {id:'baseball',label:'⚾ Baseball',title:'Baseball'},
 {id:'mma',label:'🥊 MMA',title:'MMA'}
];
const filtersBySport={football:['Tous','En direct','A venir','Premier League','La Liga','Serie A','Ligue 1'],basketball:['Tous','Live','NBA','EuroLeague','ACB','Bet on quarters'],tennis:['Tous','Live','ATP','WTA','Grand Slam','Sets'],handball:['Tous','Live','EHF','Champions League','International'],volleyball:['Tous','Live','Champions League','Nations League','Clubs'],hockey:['Tous','Live','NHL','KHL','Champions League'],rugby:['Tous','Live','Top 14','Premiership','Rugby Championship'],baseball:['Tous','Live','MLB','NPB','KBO'],mma:['Tous','Live','UFC','PFL','Bellator']};
const markets={
 football:{'Match':[ ['Résultat du match',['1','X','2']],['Double chance',['1X','12','X2']],['Draw No Bet',['Domicile','Extérieur']],['Handicap',['Domicile -1','Extérieur +1']],['Qualification',['Domicile','Extérieur']],['Mi-temps / Fin',['1/1','X/1','2/2','X/X']] ],'Buts':[ ['Total buts',['+0.5','-0.5','+1.5','-1.5','+2.5','-2.5','+3.5','-3.5']],['BTTS',['Oui','Non']],['Buts 1ère mi-temps',['+0.5','-0.5','+1.5','-1.5']],['Score exact',['0-0','1-0','1-1','2-0','2-1','2-2']],['Premier but',['Domicile','Extérieur','Aucun']] ],'Corners':[ ['Total corners',['+7.5','-7.5','+8.5','-8.5','+9.5','-9.5','+10.5','-10.5']],['Handicap corners',['Domicile -1','Domicile +1','Extérieur -1','Extérieur +1']],['Race to corners',['3','5','7','9']],['Premier corner',['Domicile','Extérieur']] ],'Cartons':[ ['Total cartons',['+2.5','-2.5','+3.5','-3.5','+4.5','-4.5']],['Premier carton',['Domicile','Extérieur','Aucun']],['Cartons 1ère mi-temps',['+0.5','-0.5','+1.5','-1.5']] ],'Joueurs':[ ['Buteur à tout moment',['Joueur 1','Joueur 2','Joueur 3']],['Premier buteur',['Joueur 1','Joueur 2','Joueur 3']],['Tirs',['+1.5','+2.5','+3.5']],['Tirs cadrés',['+0.5','+1.5','+2.5']],['Passe décisive',['Oui','Non']] ]},
 basketball:{groups:{"Match":[["Vainqueur",["1","2"]],["Handicap principal",["1 (-4.5)","2 (+4.5)","1 (-7.5)","2 (+7.5)"]],["Total points",["Plus de 159.5","Moins de 159.5","Plus de 169.5","Moins de 169.5"]],["Total équipe domicile",["Plus de 79.5","Moins de 79.5","Plus de 89.5","Moins de 89.5"]],["Total équipe extérieur",["Plus de 79.5","Moins de 79.5","Plus de 89.5","Moins de 89.5"]],["Pair / Impair",["Pair","Impair"]],["Prolongation",["Oui","Non"]]],"Périodes":[["Vainqueur 1er quart",["1","2"]],["Vainqueur 2e quart",["1","2"]],["Vainqueur 3e quart",["1","2"]],["Vainqueur 4e quart",["1","2"]],["Vainqueur mi-temps",["1","2","Égalité"]],["Handicap 1er quart",["1 (-1.5)","2 (+1.5)"]],["Handicap 2e quart",["1 (-1.5)","2 (+1.5)"]],["Handicap 3e quart",["1 (-1.5)","2 (+1.5)"]],["Handicap 4e quart",["1 (-1.5)","2 (+1.5)"]],["Total 1er quart",["Plus de 39.5","Moins de 39.5","Plus de 44.5","Moins de 44.5"]],["Total 2e quart",["Plus de 39.5","Moins de 39.5","Plus de 44.5","Moins de 44.5"]],["Total 3e quart",["Plus de 39.5","Moins de 39.5","Plus de 44.5","Moins de 44.5"]],["Total 4e quart",["Plus de 39.5","Moins de 39.5","Plus de 44.5","Moins de 44.5"]],["Plus gros quart-temps",["1er","2e","3e","4e"]]],"Équipes":[["Équipe domicile - points",["Plus de 79.5","Moins de 79.5","Plus de 89.5","Moins de 89.5"]],["Équipe extérieur - points",["Plus de 79.5","Moins de 79.5","Plus de 89.5","Moins de 89.5"]],["Domicile - 1er quart",["Plus de 19.5","Moins de 19.5","Plus de 24.5","Moins de 24.5"]],["Extérieur - 1er quart",["Plus de 19.5","Moins de 19.5","Plus de 24.5","Moins de 24.5"]],["Domicile - mi-temps",["Plus de 39.5","Moins de 39.5","Plus de 44.5","Moins de 44.5"]],["Extérieur - mi-temps",["Plus de 39.5","Moins de 39.5","Plus de 44.5","Moins de 44.5"]],["Première équipe à 20 points",["1","2","Aucune"]],["Équipe marquant le plus",["1","2","Égalité"]]],"Joueurs":[["Points joueur",["Plus de 9.5","Moins de 9.5","Plus de 19.5","Moins de 19.5","Plus de 29.5","Moins de 29.5"]],["Rebonds joueur",["Plus de 4.5","Moins de 4.5","Plus de 7.5","Moins de 7.5","Plus de 9.5","Moins de 9.5"]],["Passes joueur",["Plus de 2.5","Moins de 2.5","Plus de 5.5","Moins de 5.5","Plus de 7.5","Moins de 7.5"]],["Tirs à 3 points",["Plus de 1.5","Moins de 1.5","Plus de 2.5","Moins de 2.5","Plus de 3.5","Moins de 3.5"]],["Points + rebonds",["Plus de 14.5","Moins de 14.5","Plus de 24.5","Moins de 24.5"]],["Points + passes",["Plus de 14.5","Moins de 14.5","Plus de 24.5","Moins de 24.5"]],["Rebonds + passes",["Plus de 9.5","Moins de 9.5","Plus de 14.5","Moins de 14.5"]],["PRA (points + rebonds + passes)",["Plus de 24.5","Moins de 24.5","Plus de 34.5","Moins de 34.5"]],["Double-double",["Oui","Non"]],["Triple-double",["Oui","Non"]]],"Scores":[["Équipe à marquer en premier",["1","2"]],["Première équipe à 10 points",["1","2","Aucune"]],["Première équipe à 20 points",["1","2","Aucune"]],["Dernière équipe à marquer",["1","2"]],["Marge de victoire",["1-5","6-10","11-15","16-20","21+"]],["Intervalle total points",["0-149","150-169","170-189","190+"]],["Score exact - équipe domicile",["80-79","90-85","100-95","110-100"]],["Score exact - équipe extérieur",["79-80","85-90","95-100","100-110"]]],"Spéciaux":[["Plus gros quart-temps",["1er","2e","3e","4e"]],["Plus gros quart - équipe",["Domicile","Extérieur"]],["Marge à la mi-temps",["Domicile","Extérieur","Égalité"]],["Marge finale",["Domicile 1-10","Domicile 11+","Extérieur 1-10","Extérieur 11+"]],["Les deux équipes 80+",["Oui","Non"]],["Les deux équipes 90+",["Oui","Non"]],["Les deux équipes 100+",["Oui","Non"]],["Overtime",["Oui","Non"]]]}},tennis:{'Match':[ ['Vainqueur',['Joueur 1','Joueur 2']],['Handicap jeux',['Joueur 1 -2.5','Joueur 1 +2.5','Joueur 2 -2.5','Joueur 2 +2.5']],['Total jeux',['+20.5','-20.5','+22.5','-22.5','+24.5','-24.5']],['Nombre de sets',['2','3','4','5']] ],'Sets':[ ['Vainqueur 1er set',['Joueur 1','Joueur 2']],['Total jeux 1er set',['+9.5','-9.5','+10.5','-10.5']],['Score exact des sets',['2-0','2-1','0-2','1-2']],['Premier à 5 jeux',['Joueur 1','Joueur 2']] ],'Jeux':[ ['Jeu décisif',['Oui','Non']],['Tie-break dans le match',['Oui','Non']],['Total jeux joueur 1',['+10.5','-10.5','+12.5','-12.5']],['Total jeux joueur 2',['+10.5','-10.5','+12.5','-12.5']] ]},
 handball:{'Match':[ ['Vainqueur',['Domicile','Extérieur']],['Double chance',['1X','12','X2']],['Handicap',['Domicile -1.5','Extérieur +1.5','Domicile +2.5','Extérieur -2.5']],['Total buts',['+49.5','-49.5','+54.5','-54.5','+59.5','-59.5']] ],'Mi-temps':[ ['Vainqueur MT',['Domicile','Nul','Extérieur']],['Total buts MT',['+24.5','-24.5','+27.5','-27.5']],['Plus de buts — mi-temps',['1ère','2ème','Égal']] ],'Équipes':[ ['Total domicile',['+24.5','-24.5','+27.5','-27.5']],['Total extérieur',['+24.5','-24.5','+27.5','-27.5']],['Premier but',['Domicile','Extérieur']],['Dernier but',['Domicile','Extérieur']] ]},
 volleyball:{'Match':[ ['Vainqueur',['Domicile','Extérieur']],['Handicap sets',['Domicile -1.5','Domicile +1.5','Extérieur -1.5','Extérieur +1.5']],['Total sets',['+3.5','-3.5','+4.5','-4.5']],['Score exact sets',['3-0','3-1','3-2','0-3','1-3','2-3']] ],'Sets':[ ['Vainqueur 1er set',['Domicile','Extérieur']],['Total points 1er set',['+44.5','-44.5','+49.5','-49.5']],['Vainqueur 2e set',['Domicile','Extérieur']],['Vainqueur 3e set',['Domicile','Extérieur']] ],'Points':[ ['Total points match',['+179.5','-179.5','+189.5','-189.5','+199.5','-199.5']],['Points domicile',['+89.5','-89.5','+94.5','-94.5']],['Points extérieur',['+89.5','-89.5','+94.5','-94.5']] ]},
 hockey:{'Match':[ ['Vainqueur',['Domicile','Extérieur']],['Résultat 3 voies',['Domicile','Nul','Extérieur']],['Handicap buts',['Domicile -1.5','Extérieur +1.5']],['Total buts',['+5.5','-5.5','+6.5','-6.5']] ],'Périodes':[ ['Vainqueur 1ère période',['Domicile','Extérieur']],['Total 1ère période',['+1.5','-1.5']],['Vainqueur 2e période',['Domicile','Extérieur']],['Vainqueur 3e période',['Domicile','Extérieur']] ],'Buts':[ ['BTTS',['Oui','Non']],['Premier but',['Domicile','Extérieur','Aucun']],['Total équipe domicile',['+2.5','-2.5','+3.5','-3.5']],['Total équipe extérieur',['+2.5','-2.5','+3.5','-3.5']] ]},
 rugby:{'Match':[ ['Vainqueur',['Domicile','Extérieur']],['Handicap points',['Domicile -5.5','Domicile +5.5','Extérieur -5.5','Extérieur +5.5']],['Total points',['+39.5','-39.5','+49.5','-49.5']],['Mi-temps / Fin',['1/1','1/2','2/1','2/2']] ],'Points':[ ['Total essais',['+4.5','-4.5','+5.5','-5.5']],['Total points MT',['+19.5','-19.5','+24.5','-24.5']],['Premier essai',['Domicile','Extérieur','Aucun']],['Dernier essai',['Domicile','Extérieur','Aucun']] ],'Spéciaux':[ ['Équipe marque 1er',['Domicile','Extérieur']],['Écart victoire',['1-5','6-10','11-20','21+']],['Prochain score',['Domicile','Extérieur','Pénalité']] ]},
 baseball:{'Match':[ ['Vainqueur',['Domicile','Extérieur']],['Run line',['Domicile -1.5','Extérieur +1.5']],['Total runs',['+7.5','-7.5','+8.5','-8.5']],['Résultat après 5 manches',['Domicile','Nul','Extérieur']] ],'Manches':[ ['Vainqueur 1ère manche',['Domicile','Extérieur']],['Total 1ère manche',['+0.5','-0.5']],['Vainqueur après 5',['Domicile','Nul','Extérieur']],['Total après 5',['+3.5','-3.5']] ],'Équipes':[ ['Runs domicile',['+3.5','-3.5','+4.5','-4.5']],['Runs extérieur',['+3.5','-3.5','+4.5','-4.5']],['Premier run',['Domicile','Extérieur','Aucun']] ]},
 mma:{'Combat':[ ['Vainqueur',['Combattant 1','Combattant 2']],['Méthode',['KO/TKO','Soumission','Décision']],['Combat va à la décision',['Oui','Non']],['Round de fin',['1','2','3','4','5']] ],'Rounds':[ ['Vainqueur round 1',['Combattant 1','Combattant 2']],['Total rounds',['+1.5','-1.5','+2.5','-2.5']],['Combat terminé avant',['Round 1','Round 2','Round 3']],['KO/TKO avant',['Round 1','Round 2','Round 3']] ],'Spéciaux':[ ['Gagne par KO/TKO',['Combattant 1','Combattant 2']],['Gagne par soumission',['Combattant 1','Combattant 2']],['Gagne par décision',['Combattant 1','Combattant 2']] ]}
};
const samples={
 basketball:[['NBA','19:30','Los Angeles Lakers','Phoenix Suns','VS'],['EuroLeague','20:00','Real Madrid','Fenerbahce','VS'],['NBA','21:00','Boston Celtics','Miami Heat','VS']],
 tennis:[['ATP','18:00','Joueur 1','Joueur 2','VS'],['WTA','19:30','Joueuse 1','Joueuse 2','VS'],['Grand Slam','21:00','Joueur 3','Joueur 4','VS']],
 handball:[['EHF','18:00','Team Alpha','Team Beta','VS'],['Champions League','20:00','Paris HB','Kiel','VS'],['International','21:00','France','Danemark','VS']],
 volleyball:[['Champions League','18:30','Trentino','ZAKSA','VS'],['Nations League','20:00','France','Italie','VS'],['Clubs','21:00','Tours','Berlin','VS']],
 hockey:[['NHL','19:00','Toronto Maple Leafs','Montreal Canadiens','VS'],['KHL','20:30','CSKA Moscow','SKA','VS']],
 rugby:[['Top 14','19:00','Toulouse','La Rochelle','VS'],['Premiership','20:00','Saracens','Leicester','VS']],
 baseball:[['MLB','19:10','New York Yankees','Boston Red Sox','VS'],['NPB','20:00','Giants','Tigers','VS']],
 mma:[['UFC','21:00','Combattant 1','Combattant 2','VS'],['PFL','22:00','Combattant 3','Combattant 4','VS']]
};
let sport='football',games=[],selections=[];
function odds(n){return (1.25+(n%10)*0.15).toFixed(2)}
function marketCount(){return Object.values(markets[sport]||{}).reduce((sum,g)=>sum+g.reduce((n,grp)=>n+grp[1].length,0),0)}
function esc(v){return String(v).replace(/'/g,"\\'")}
function renderSports(){document.querySelector('#sports').innerHTML=sports.map(s=>`<button class="${s.id===sport?'active':''}" onclick="setSport('${s.id}')">${s.label}</button>`).join('')}
function renderFilters(){document.querySelector('#filters').innerHTML=(filtersBySport[sport]||['Tous','Live']).map((x,i)=>`<button class="filter ${i===0?'active':''}">${x}</button>`).join('')}
function sampleGames(id){return (samples[id]||[]).map((x,i)=>({league:x[0],time:x[1],home:x[2],away:x[3],score:x[4],live:false,od:id==='football'?['1.90','3.60','3.90']:['1.75','1.95','2.05']}))}
function statusLabel(g){return g.live?`● LIVE${g.elapsed?` ${g.elapsed}'`:''}`:'Pré-match'}
function render(){
 renderSports();renderFilters();
 const title=sports.find(x=>x.id===sport)?.title||'Sports';document.querySelector('#heroTitle').textContent=title;document.querySelector('#heroSub').textContent=`Marchés nombreux et adaptés à ${title} • sélections virtuelles`;
 document.querySelector('#matches').innerHTML=games.length?games.map((g,i)=>`<article class="match"><div class="mhead"><span>${g.league} • ${g.time}</span><span class="${g.live?'live':''}">${statusLabel(g)}</span></div><div class="teams"><div class="team">${g.home}</div><div class="score">${g.score||'VS'}</div><div class="team away">${g.away}</div></div><div class="quick"><button class="odd" onclick="add('${esc(g.home)} — ${esc(g.away)}','${sport==='football'?'1':sport==='tennis'?'Joueur 1':'Domicile'}',${g.od[0]})"><small>Principal</small><strong>${g.od[0]}</strong></button><button class="odd" onclick="add('${esc(g.home)} — ${esc(g.away)}','${sport==='football'?'X':sport==='tennis'?'Joueur 2':'Extérieur'}',${g.od[1]})"><small>${sport==='football'?'X':'Opposant'}</small><strong>${g.od[1]}</strong></button><button class="odd" onclick="openMarkets(${i},Object.keys(markets[sport])[1]||Object.keys(markets[sport])[0])"><small>+ Marchés</small><strong>${marketCount()}+</strong></button></div><button class="more" onclick="openMarkets(${i},Object.keys(markets[sport])[0])">＋ Voir les marchés · ${marketCount()} choix</button></article>`).join(''):`<div class="emptyState"><b>Aucun match disponible</b><br>Les matchs disponibles apparaîtront ici automatiquement.</div>`;
}
function setSport(id){
 sport=id;
 games=id==='football'?[...fallbackFootball]:[];
 render();
 if(id==='basketball') loadBasketball();
 else if(id!=='football') loadSport(id);
}
function normalizeSportGame(x,id){
 const date=x.date||x.fixture?.date||x.fight?.date;
 const st=x.status?.short||x.status?.long||x.fixture?.status?.short||'';
 const live=['Q1','Q2','Q3','Q4','OT','HT','BT','1H','2H','LIVE','IN PLAY'].includes(String(st).toUpperCase());
 const finished=['FT','AOT','AET','FINAL','FINISHED'].includes(String(st).toUpperCase());
 const home=x.teams?.home?.name||x.players?.home?.name||x.fighters?.home?.name||x.home?.name||x.home||'Domicile';
 const away=x.teams?.away?.name||x.players?.away?.name||x.fighters?.away?.name||x.away?.name||x.away||'Extérieur';
 const hs=x.scores?.home?.total??x.scores?.home??x.score?.home??x.goals?.home??null;
 const as=x.scores?.away?.total??x.scores?.away??x.score?.away??x.goals?.away??null;
 return {id:x.id||x.fixture?.id||x.game?.id,league:x.league?.name||x.event?.name||x.competition?.name||id.toUpperCase(),time:date?formatTime(date):'--:--',home,away,live,elapsed:x.status?.elapsed||x.fixture?.status?.elapsed||null,score:(live||finished)&&hs!=null&&as!=null?`${hs} - ${as}`:'VS',od:['1.75','1.95','2.05']}
}
async function loadBasketball(){
  const matchesBox=document.querySelector('#matches');
  try{
    matchesBox.innerHTML='<div class="emptyState"><b>Chargement du Basketball…</b>Connexion aux données en cours.</div>';

    const today=new Date().toISOString().slice(0,10);
    const url=`${API_BASKETBALL}?date=${today}&timezone=Africa/Tunis`;

    const r=await fetch(url,{
      method:'GET',
      cache:'no-store',
      headers:{'Accept':'application/json'}
    });

    const text=await r.text();
    let data={};
    try{data=JSON.parse(text)}catch{
      throw new Error(`Réponse serveur invalide (HTTP ${r.status})`);
    }

    if(!r.ok){
      throw new Error(data.error||data.message||`Erreur HTTP ${r.status}`);
    }

    if(!Array.isArray(data.response)){
      throw new Error('Format de réponse Basketball invalide');
    }

    games=data.response
      .map(x=>normalizeSportGame(x,'basketball'))
      .filter(x=>x && x.home && x.away)
      .slice(0,60);

    console.log('BETZ Basketball:',games.length,'matchs',data);

    render();

    if(!games.length){
      matchesBox.innerHTML='<div class="emptyState"><b>Aucun match de Basketball aujourd’hui</b><br>Les données sont bien connectées, mais aucun match n’est retourné pour cette date.</div>';
    }
  }catch(e){
    console.error('BETZ Basketball ERROR:',e);
    games=[];
    render();
    matchesBox.innerHTML=`<div class="emptyState"><b>Basketball indisponible</b><br>Impossible de charger les matchs pour le moment.<br><small>${String(e.message||e)}</small></div>`;
  }
}
async function loadSport(id){
 try{
   const today=new Date().toISOString().slice(0,10);
   const r=await fetch(`${API_SPORTS}?sport=${encodeURIComponent(id)}&date=${today}`);
   const data=await r.json();
   if(!r.ok) throw new Error(data.error||'API error');
   const fresh=(data.response||[]).map(x=>normalizeSportGame(x,id));
   games=fresh.slice(0,60);
   render();
 }catch(e){
   console.warn(id+' API unavailable',e);
   games=[];
   render();
 }
}
const fallbackFootball=[{league:'Premier League',time:'20:00',home:'Manchester City',away:'Arsenal',live:false,od:['1.72','3.80','4.60'],score:'VS'},{league:'La Liga',time:'21:00',home:'Real Madrid',away:'Barcelona',live:false,od:['2.05','3.60','3.20'],score:'VS'},{league:'Serie A',time:'19:45',home:'Inter',away:'Juventus',live:false,od:['1.90','3.45','4.10'],score:'VS'}];
function openMarkets(i,cat){
 const g=games[i];const cats=Object.keys(markets[sport]||{});if(!cat||!markets[sport]?.[cat])cat=cats[0];
 document.querySelector('#modalTitle').textContent=g.home+' — '+g.away;
 document.querySelector('#modalSport').textContent=(sports.find(x=>x.id===sport)?.title||sport);
 document.querySelector('#tabs').innerHTML=cats.map(c=>`<button class="${c===cat?'on':''}" onclick="openMarkets(${i},'${esc(c)}')">${c}</button>`).join('');
 document.querySelector('#marketSearch').value='';
 document.querySelector('#marketgrid').dataset.gameIndex=i;
 document.querySelector('#marketgrid').dataset.category=cat;
 renderMarketCategory(i,cat,'');
 document.querySelector('#modal').classList.add('open');
 markSelectedMarkets();
}
function renderMarketCategory(i,cat,query){
 const g=games[i], q=(query||'').trim().toLowerCase();
 const groups=markets[sport][cat]||[];
 let visible=0;
 const html=groups.map((grp,gi)=>{
   const rows=grp[1].map((x,n)=>{
     const market=grp[0]+': '+x;
     if(q && !(x+' '+grp[0]).toLowerCase().includes(q)) return '';
     visible++;
     const match=g.home+' — '+g.away;
     const key=selectionKey(match,market);
     const active=selections.some(s=>s.key===key);
     const odd=odds(n+gi);
     return `<div class="betrow"><span>${x}</span><button class="${active?'selected':''}" data-key="${esc(key)}" onclick="add('${esc(match)}','${esc(market)}',${odd})">${active?'✓ ':''}${odd}</button></div>`;
   }).join('');
   if(!rows) return '';
   return `<section class="group"><div class="gtitle">${grp[0]}</div><div class="rows">${rows}</div></section>`;
 }).join('');
 document.querySelector('#marketgrid').innerHTML=html||`<div class="emptyState" style="margin:12px">Aucun marché trouvé<br><small>Essayez un autre terme.</small></div>`;
 document.querySelector('#marketCount').textContent=visible+' marché'+(visible===1?'':'s');
 document.querySelector('#marketSelectedCount').textContent=selections.length+' sélection'+(selections.length===1?'':'s');
}
function filterMarkets(query){
 const i=Number(document.querySelector('#marketgrid').dataset.gameIndex||0);
 const cat=document.querySelector('#marketgrid').dataset.category||Object.keys(markets[sport]||{})[0];
 renderMarketCategory(i,cat,query);
}
function closeModal(){document.querySelector('#modal').classList.remove('open')}
document.querySelector('#modal')?.addEventListener('click',e=>{if(e.target.id==='modal')closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();document.querySelector('#slip')?.classList.remove('expanded')}})
let slipMode='combo';
function selectionKey(match,market){return match+'||'+market}
function add(match,market,odd){
 const key=selectionKey(match,market);
 const existing=selections.findIndex(s=>s.key===key);
 if(existing>=0){selections.splice(existing,1)}else{selections.push({key,match,market,odd:Number(odd)})}
 renderSlip();
 const slip=document.querySelector('#slip');
 slip.classList.remove('bump');
 void slip.offsetWidth;
 slip.classList.add('bump');
 setTimeout(()=>slip.classList.remove('bump'),320);
 markSelectedMarkets();
 const mc=document.querySelector('#marketSelectedCount'); if(mc) mc.textContent=selections.length+' sélection'+(selections.length===1?'':'s');
}
function removeSelection(i){selections.splice(i,1);renderSlip();markSelectedMarkets()}
function clearSlip(){selections=[];renderSlip();markSelectedMarkets()}
function setStake(v){document.querySelector('#stake').value=v;updatePotential(Number(document.querySelector('#total').textContent||1))}
function setSlipMode(mode){slipMode=mode;document.querySelector('#tabCombo').classList.toggle('on',mode==='combo');document.querySelector('#tabSimple').classList.toggle('on',mode==='simple');renderSlip()}
function renderSlip(){
 const n=selections.length;
 document.querySelector('#count').textContent=n;
 const body=document.querySelector('#slipbody');
 if(!n){body.innerHTML='<div class="empty">Choisissez des marchés pour les ajouter au coupon.</div>'}
 else if(slipMode==='simple'){
   body.innerHTML=selections.map((s,i)=>`<div class="pick"><button class="remove" onclick="removeSelection(${i})">✕</button><b>${s.market}</b><span class="matchline">${s.match}</span><span class="oddline"><span>Mise individuelle</span><strong>${s.odd.toFixed(2)}</strong></span></div>`).join('')
 }else{
   body.innerHTML=selections.map((s,i)=>`<div class="pick"><button class="remove" onclick="removeSelection(${i})">✕</button><b>${s.market}</b><span class="matchline">${s.match}</span><span class="oddline"><span>Sélection ${i+1}</span><strong>${s.odd.toFixed(2)}</strong></span></div>`).join('')
 }
 const total=selections.reduce((a,s)=>a*s.odd,1);
 document.querySelector('#total').textContent=n?total.toFixed(2):'1.00';
 updatePotential(total);
 document.querySelector('#confirmBtn').disabled=!n;
}
function updatePotential(total){
 const stake=Math.max(0,Number(document.querySelector('#stake')?.value||0));
 let rate=0;
 if(selections.length>=15)rate=.10; else if(selections.length>=10)rate=.05;
 const bonus=slipMode==='combo'?stake*rate:0;
 const potential=slipMode==='combo'?(stake*total)+bonus:(stake*selections.reduce((a,s)=>a+s.odd,0)/Math.max(1,selections.length));
 document.querySelector('#bonus').textContent=bonus.toFixed(2).replace('.',',');
 document.querySelector('#potential').textContent=potential.toFixed(2).replace('.',',');
}
function toggleSlip(){document.querySelector('#slip').classList.toggle('expanded')}
function closeSlip(){document.querySelector('#slip').classList.remove('expanded')}
function confirmSlip(){if(!selections.length)return;alert('Coupon virtuel enregistré — aucune transaction réelle.')}
function markSelectedMarkets(){
 document.querySelectorAll('#marketgrid .betrow button').forEach(btn=>{
   const k=btn.dataset.key;
   btn.classList.toggle('selected',!!k&&selections.some(s=>s.key===k));
 })
}
document.addEventListener('input',e=>{if(e.target.id==='stake')updatePotential(Number(document.querySelector('#total').textContent||1))})
function formatTime(ts){try{return new Date(ts).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}catch{return '--:--'}}
function normalizeFixture(x){const st=x.fixture?.status?.short||'';const live=['1H','HT','2H','ET','P','BT','LIVE'].includes(st);const finished=['FT','AET','PEN'].includes(st);return {league:x.league?.name||'Football',time:formatTime(x.fixture?.date),home:x.teams?.home?.name||'Domicile',away:x.teams?.away?.name||'Extérieur',live,elapsed:x.fixture?.status?.elapsed||null,score:live||finished?`${x.goals?.home??0} - ${x.goals?.away??0}`:'VS',od:live||finished?['1.85','3.50','4.20']:['1.90','3.60','3.90']}}
async function loadFootball(){try{const today=new Date().toISOString().slice(0,10);const [a,b]=await Promise.all([fetch(`${API_FOOTBALL}?date=${today}`),fetch(`${API_FOOTBALL}?live=all`)]);const day=await a.json(),live=await b.json();const map=new Map();[...(day.response||[]),...(live.response||[])].forEach(x=>map.set(x.fixture?.id,x));const fresh=[...map.values()].map(normalizeFixture);if(fresh.length){games=fresh.slice(0,60);render()}}catch(e){console.warn('Football API unavailable',e)}}
setSport('football');loadFootball();setInterval(()=>{if(sport==='football')loadFootball();else if(sport==='basketball')loadBasketball();else loadSport(sport)},120000);
